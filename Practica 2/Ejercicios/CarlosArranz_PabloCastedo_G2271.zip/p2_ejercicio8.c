#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#define N_READ 3
#define SECS 2


int pid_hijos[N_READ];
int lectores=0;
int pid_padre;

    void manejador(int sig){
        int i;

        if(getpid()!=pid_padre){
            sleep(3);
            return;
        }

        printf("\nHe conseguido capturar SIGINT soy el pid = %d\n",getpid());


        fflush(stdout);

        sem_unlink("/SEM_ESCRIT");
        sem_unlink("/SEM_LECT");

        for(i=0;i<N_READ;i++){
            kill(pid_hijos[i],SIGTERM);
        }

        fflush(stdout);
        
        exit(EXIT_SUCCESS);
    }



    void Lectura(sem_t * sem_lectura, sem_t * sem_escritura) {

        sem_wait(sem_lectura);
        
        lectores++;     

        if (lectores == 1){
            sem_wait(sem_escritura);
        }
        sem_post(sem_lectura);
        
        /*--------LEER------------*/
        printf("\nR-INI %d",getpid());
        sleep(1);
        printf("\nR-FIN %d",getpid());
        fflush(stdout);
        /*--------FIN LEER------------*/


        sem_wait(sem_lectura);
        lectores--;
        if (lectores == 0){
            sem_post(sem_escritura);
        }

        sem_post(sem_lectura);     

    }


    void Escritura(sem_t * sem_escritura) {


        sem_wait(sem_escritura);


        /*--------ESCRIBIR------------*/
        printf("\nW-INI %d",getpid());
        sleep(1);
        printf("\nW-FIN %d",getpid());
        fflush(stdout);

        /*--------FIN ESCRIBIR-----------*/

        sem_post(sem_escritura);

        
    }

    int main(){

        int i,pid;
        sem_t * sem_lectura=NULL;
        sem_t * sem_escritura=NULL;

        //Por si hay problemas de que el semaforo ya existe
        //sem_unlink("/SEM_ESCRIT");
        //sem_unlink("/SEM_LECT");

        pid_padre=getpid();

        printf("\nSoy el padre con pid = %d\n",pid_padre);

        if ((sem_lectura = sem_open("/SEM_LECT", O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, N_READ)) == SEM_FAILED) {
            perror("sem_open");
            exit(EXIT_FAILURE);
        }

        if ((sem_escritura = sem_open("/SEM_ESCRIT", O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1)) == SEM_FAILED) {
            perror("sem_open");
            exit(EXIT_FAILURE);
        }


        struct sigaction act;
        act.sa_handler = manejador;
        sigemptyset(&(act.sa_mask));
        act.sa_flags =0;

        if(sigaction(SIGINT,&act,NULL)<0){
            perror("sigaction");
            exit(EXIT_FAILURE);
        }

        for(i=0;i<N_READ;i++){

            pid=fork();
            if(pid==0){
                pid_hijos[i]=getpid();
                break;
            }
        }

        if(pid==0){
            //hijos lectores
            while(1){
                Lectura(sem_lectura,sem_escritura);
                sleep(SECS);
                
            }


        }
        else{
            //padre escritor
            while(1){
                Escritura(sem_escritura);
                sleep(SECS);

            }
        }


        return 0;

}